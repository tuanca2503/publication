import pathlib
import re
from setuptools import setup

VERSION = "0.1.0"
PACKAGE = "MetaUtils"
setup(
    name="MetaUtils",              # Tên trên PyPI
    version="0.1.0",                       # Phiên bản
    packages=[PACKAGE],           
    install_requires=[
        "psutil==7.0.0",
        "pympler"
    ],                 # Dependencies nếu có
    author="MetaPhobius",
    author_email="metaphobius@gmail.com",
    description="Using for me",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://tuanca2503.github.io/",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.12',
)
#===========================================================
init_file = pathlib.Path(PACKAGE) / "__init__.py"
if init_file.exists():
    content = init_file.read_text()
    if "__version__" in content:
        # Thay thế dòng __version__ cũ
        content = re.sub(r'__version__\s*=\s*".*"', f'__version__ = "{VERSION}"', content)
    else:
        # Nếu chưa có thì thêm vào cuối file
        content += f'\n__version__ = "{VERSION}"\n'
    init_file.write_text(content)
#===========================================================