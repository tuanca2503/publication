# import metautils as utils

# # In ra các module/submodule
# log = utils.Log("test")
# log.info("abc")
from MetaUtils import *

# suit = utils.TestSuit()

# def test():
#     return 1+1

# suit.add("test",test,2)
# suit.run()

